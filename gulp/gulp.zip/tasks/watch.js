'use strict';

module.exports = function() {
  $.gulp.task('watch', function() {
    $.gulp.watch('./app/js/**/*.js', $.gulp.series('js:process'));
    $.gulp.watch('./app/scss/**/*.scss', $.gulp.series('sass'));
    $.gulp.watch('./app/templates/**/*.pug', $.gulp.series('pug'));
    $.gulp.watch('./app/assets/img/**/*.*', $.gulp.series('copy:image'));
  });
};
