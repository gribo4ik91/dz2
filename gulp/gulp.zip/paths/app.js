'use strict';

module.exports = [
  './app/js/main.js'
];