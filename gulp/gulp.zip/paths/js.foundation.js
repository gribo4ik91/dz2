'use strict';

module.exports = [
  './bower_components/jquery/dist/jquery.min.js'
];
