'use strict';

module.exports = [
  './node_modules/normalize.css/normalize.css'
];
